# Library Management System_Django
 This Project is for Library management system that is created under python programming language along side DJANGO framework, user can upload a book, upload the existing book, delete a book from the list and view all the uploaded books
